from colorama import init
from colorama import Fore
init(autoreset=True)
def main():
    print(Fore.RED + 'Hello!')


if __name__ == '__main__':
    main()
